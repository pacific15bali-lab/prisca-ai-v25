# V20 — Content + SEO + Social Operations Layer

V20 expands Prisca from a package builder into a broader AI Operations Manager foundation.

## Added
- `content_worker.py` provider-agnostic content/SEO/social planning engine.
- Multi-platform asset generation contracts for Instagram, Facebook, YouTube, Pinterest, Google Business and website.
- 7-day (up to 31-day) content calendar generation.
- SEO keyword/cluster planning.
- Persistent content asset, calendar and SEO audit tables.
- Safe-by-default publishing block: generated assets are drafts and no external platform is published automatically.
- Service-authenticated endpoints:
  - `POST /api/ai/content-assets`
  - `POST /api/ai/content-calendar`
  - `POST /api/ai/seo-plan`
- Admin read endpoints:
  - `GET /api/content-assets`
  - `GET /api/content-calendars`

## Philosophy
Content generation is separated from publishing. Real platform connectors can be attached later, with per-platform approval/auto-publish controls.
