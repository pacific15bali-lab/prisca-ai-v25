# CPanel Deployment — Prisca Smart Package Builder V16

## Recommended hosting model

Use CPanel as the first production host, but keep the application portable. The backend must run on the server; users only need a browser. Do not put WordPress credentials or the service key in the Android app.

## 1. Create a subdomain

Recommended:
- `app.prisca-ai.com` for the human web console
- `api.prisca-ai.com` later if the API is separated

Enable SSL/HTTPS in CPanel.

## 2. Python environment

Use CPanel's **Setup Python App** if available. Select Python 3.10+ (3.11/3.12 preferred if all dependencies pass). Upload the project outside `public_html` where possible.

Install:

```bash
pip install -r requirements.txt
```

If the hosting provider does not support persistent Python applications, do not expose the development server directly to the Internet. Move the backend to a VPS/cloud host while CPanel continues to host the public website/email.

## 3. Environment variables

Copy `.env.example` to `.env` and set real values. Never commit `.env` or send credentials through chat.

Required for AI-to-Pricing API:

`PRISCA_SERVICE_KEY=<long random secret>`

Required for WordPress connector:

`PRISCA_WP_URL=https://www.priscaholidays.com`
`PRISCA_WP_USER=<WordPress integration user>`
`PRISCA_WP_APP_PASSWORD=<WordPress Application Password>`

## 4. Database and writable folders

The current V16 build uses SQLite. Keep `data/` writable by the application and back it up daily.

Writable:
- `data/`
- `uploads/`

The `.privacy.key` file under `data/` must be backed up securely because encrypted personal-data fields depend on it.

## 5. Production rules

- HTTPS only.
- Strong unique service key.
- Disable demo credentials before production.
- Change admin password immediately.
- Restrict admin creation to admin users.
- Keep WordPress credentials server-side.
- Start with WordPress read-only audit and WooCommerce draft creation only.
- Do not enable automatic publishing until approval/audit logging is complete.
- Do not expose SQLite or `.env` through `public_html`.

## 6. Health check

`GET /api/health` returns the service and version. Use it from an external monitor later.

## 7. Scaling path

CPanel/SQLite is the low-cost MVP. If usage grows, move the same application to a VPS/container with PostgreSQL and a proper reverse proxy. Keep the API contracts unchanged so the Android app and AI Worker do not need a rewrite.

## V22 Scheduler / Cron
In cPanel Cron Jobs, run the scheduler every 5 minutes (or hourly if preferred):

`*/5 * * * * curl -fsS -H "X-PRISCA-SERVICE-KEY: YOUR_SERVICE_KEY" "https://app.example.com/api/cron/run?limit=20" >/dev/null 2>&1`

Keep the service key in the cron command/server environment, never in browser JavaScript. Public publishing is still blocked unless the content asset has been approved.

## Website Lead Webhook
Set this server environment variable in cPanel:
`PRISCA_LEAD_WEBHOOK_SECRET=<long-random-secret>`

POST JSON to:
`https://YOUR-DOMAIN/api/leads/webhook`
with header:
`X-Prisca-Lead-Secret: <same-secret>`

Example payload:
```json
{
  "name":"Rahul Sharma",
  "phone":"+91 9876543210",
  "email":"rahul@example.com",
  "source":"wpforms",
  "destination":"Kerala",
  "travel_date":"2027-01-15",
  "travellers":2,
  "budget":60000,
  "message":"Need a honeymoon package"
}
```

Configure WPForms/WooCommerce/other website form tooling to call this endpoint. Keep the secret server-side and never expose it in browser JavaScript.
