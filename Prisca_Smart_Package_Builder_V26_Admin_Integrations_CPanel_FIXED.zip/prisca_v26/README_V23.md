# Prisca Smart Package Builder V23

V23 expands the system into the **Prisca AI Operations Manager** with Sales & Lead Operations.

## New Sales Layer
- Lead intake and pipeline
- Lead ownership
- Follow-up scheduling
- Lead event history
- Sales task management
- Pipeline dashboard

## Safety
No WhatsApp, email, SMS or external sales message is sent automatically by V23. Outbound communications should be connected only through approved provider APIs and explicit workflow rules.

## CPanel
Keep the app behind HTTPS and configure a cron job to call the existing scheduler. Store secrets only in environment variables/server-side configuration.
