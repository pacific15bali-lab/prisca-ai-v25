# Prisca AI Operations Manager V21

V21 expands the V20 content/SEO worker into a credential-gated platform integration and analytics layer.

## Added
- Integration status registry: Meta/Facebook/Instagram, YouTube, Pinterest, Google Search Console, Bing Webmaster and WordPress.
- Human approval gate before external publishing.
- Publishing audit log and social/SEO metric storage.
- Google Search Console analytics ingestion.
- Bing URL submission adapter.
- Pinterest Pin creation adapter.
- Meta Facebook Page and Instagram image publishing adapter.
- YouTube OAuth-aware adapter scaffold; upload requires a real media file and a correctly configured resumable upload flow.
- CPanel-friendly environment configuration.

## Safety
No credentials are bundled. External publishing requires both authenticated admin approval and configured provider credentials. Website/WooCommerce publishing remains draft-first.

## Current limitation
Google Business Profile publishing is intentionally not enabled in this build. YouTube media upload is staged behind the media-worker because video uploads require resumable media handling and account/project authorization. These can be added without changing the database contract.
