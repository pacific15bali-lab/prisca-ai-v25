# Prisca Smart Package Builder V20

This build adds the Content, SEO and Social Operations layer on top of V19.

The system is still safe-by-default: it generates plans/assets but does not publish to Facebook, Instagram, YouTube, Pinterest, Google Business Profile or the website automatically.

Use the existing CPanel deployment instructions from `CPANEL_DEPLOYMENT.md`.
