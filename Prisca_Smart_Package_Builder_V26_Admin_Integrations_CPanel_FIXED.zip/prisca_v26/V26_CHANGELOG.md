# Prisca AI Operations Manager V26

## Admin-only Settings & Integrations

V26 centralizes infrastructure and social integrations inside **Settings & Integrations**. Only users with the `admin` role can see or use this area.

### Integrations
- WordPress + WooCommerce
- cPanel / Passenger deployment
- Facebook
- Instagram
- YouTube
- Google Search Console / Analytics configuration
- Pinterest
- Bing Webmaster

Credentials are stored server-side and secret values are encrypted in the local database when `cryptography` is available. Secret values are never returned by the configuration GET endpoint.

## cPanel one-click deployment

The cPanel panel supports:
1. Test cPanel connection.
2. Upload the Prisca application files through cPanel UAPI Fileman.
3. Register the application through PassengerApps.
4. Attempt dependency installation and enablement.

API tokens are preferred over cPanel passwords. The configured app domain must already exist/resolve to the cPanel account, and the hosting plan must support Python WSGI/Passenger. If the host does not provide Passenger/Python support, the installer reports the failure instead of pretending the deployment succeeded.

The Python WSGI adapter is provided in `wsgi.py` and `passenger_wsgi.py`.

## AI command box

Admin users can issue natural-language package planning commands such as:

> Create 20 packages for Kerala using the existing package structure and keep minimum 15% gross margin.

V26 converts this into structured package drafts. Research, supplier costing, QA and human approval remain required; publishing is not automatic.

## Security

- Integration endpoints are Admin-only.
- Secret fields are masked and blank values preserve previously stored secrets.
- Login responses no longer return the password hash.
- Public publishing remains approval-gated.
- cPanel deployment requires an authenticated Admin session.
