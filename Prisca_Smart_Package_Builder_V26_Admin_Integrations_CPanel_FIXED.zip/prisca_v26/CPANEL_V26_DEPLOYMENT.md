# V26 cPanel deployment

## Recommended setup

Create a subdomain such as `app.prisca-ai.com` and point its DNS to the same cPanel account/server. The cPanel account must support Python WSGI/Passenger/Application Manager.

From Prisca AI:

`Settings & Integrations → cPanel`

Enter:
- cPanel URL, normally the HTTPS cPanel host on port 2083
- cPanel username
- API token (preferred) or password
- application directory, e.g. `prisca_ai`
- application domain, e.g. `app.prisca-ai.com`

Then use **Test cPanel**, followed by **Connect & Install Prisca AI**.

The installer uses cPanel UAPI for file uploads and PassengerApps registration. cPanel's current documentation recommends UAPI for API integrations and supports API-token authentication. The application itself exposes a WSGI adapter for Passenger.

If the host does not support Passenger/Python WSGI, use a VPS/cloud Python deployment instead.
