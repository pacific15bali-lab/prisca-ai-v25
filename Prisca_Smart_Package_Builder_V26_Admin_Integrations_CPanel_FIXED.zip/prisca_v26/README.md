# Prisca Smart Package Builder V17 AI Worker

Development build extending V15 without replacing the existing package builder.

## V17 AI Worker changes
- Adds a reusable central gross-margin pricing engine.
- Adds `POST /api/pricing/calculate` for the future Prisca AI Worker.
- Adds configurable `online_package_margin` (default 15%).
- Keeps legacy package-category pricing behavior unless the request category is `online`, `website`, or `published`.
- Adds an Activities data model/API for future supplier activity costing.
- Existing V15 UI and package generation remain intact.

## Run on Windows
Double-click `run.bat` or run `python app.py`.

The app runs locally at http://127.0.0.1:8765.

## Demo credentials
Admin: `admin@priscaholidays.local` / `admin123`
Agent: `agent@priscaholidays.local` / `agent123`

## Pricing API example
POST `/api/pricing/calculate`

```json
{
  "target_margin_percent": 15,
  "commercial_rounding": true,
  "components": [
    {"type": "hotel", "name": "Munnar Hotel", "amount": 12000},
    {"type": "transport", "name": "Sedan", "amount": 10000},
    {"type": "activity", "name": "Sightseeing", "amount": 3000}
  ]
}
```

The API returns supplier cost, exact calculated selling price, recommended commercial price, and actual margin after rounding.

This is still a development build. Do not use real Aadhaar/PAN or production credentials.

## AI Worker / WordPress connector

`wordpress_connector.py` is a separate, non-destructive connector for the Prisca AI Worker.

Environment variables:
- `PRISCA_WP_URL` — e.g. `https://www.priscaholidays.com`
- `PRISCA_WP_USER` — WordPress administrator/service user
- `PRISCA_WP_APP_PASSWORD` — WordPress Application Password
- `PRISCA_SERVICE_KEY` — private key for backend-to-backend calls to the pricing engine

The connector can audit site metadata, WooCommerce products/categories and (if the account permits it) plugins. Product creation is explicitly draft-only.

Recommended workflow:
1. AI Worker reads/audits WordPress.
2. AI Worker researches and builds package data.
3. AI Worker sends supplier cost components to the V17 AI Worker pricing engine.
4. AI Worker creates a WooCommerce **draft** only.
5. Human reviews/approves.
6. Publishing remains a separate action.

Never place WordPress credentials or `PRISCA_SERVICE_KEY` in an Android APK or source-controlled frontend.

## AI Worker v1

The server now includes a safe orchestration layer in `ai_worker.py`:
- `/api/ai/wordpress-audit` — authenticated, read-only WordPress/WooCommerce audit.
- `/api/ai/package-prepare` — validates a normalized package and returns an approval-ready QA result; no WordPress write.
- `/api/ai/package-draft` — creates a WooCommerce **draft only** after QA passes; it cannot publish.

All AI Worker endpoints require `X-Prisca-Service-Key`. WordPress credentials remain server-side.

## V18 template and approval workflow
- `GET /api/ai/package-template?product_id=ID` reads an existing WooCommerce product and returns a normalized Prisca content template.
- `POST /api/ai/approval-request` validates a package and stores it in the approval queue without touching WordPress.
- Admin UI/API can review with `GET /api/package-approvals`.
- `POST /api/package-approvals/review` with `approval_id` + `decision=approve|reject` requires an authenticated admin. Approval creates a WooCommerce **draft** only; publishing remains manual.
