# V23 — Sales & Lead Operations

Adds the first Sales/Lead worker layer to the Prisca AI Operations Manager.

## Added
- Leads database with source, destination, travel date, traveller count, budget, stage, priority, owner and follow-up fields.
- Lead event timeline for calls, notes, stage changes and tasks.
- Sales task queue with owners, due dates and completion state.
- Sales dashboard endpoint for pipeline counts and due follow-ups.
- Lead create/update/event APIs.
- Sales task create/complete APIs.
- Safe-by-default: no outbound WhatsApp/email/SMS is sent by this layer.
- Existing V22 content/SEO/social/approval/scheduler functionality preserved.

## Pipeline
New → Contacted → Qualified → Proposal → Negotiation → Won/Lost

The next integration layer can connect approved lead sources (website forms, Meta, email/CRM) and add outbound follow-up adapters behind human approval.
