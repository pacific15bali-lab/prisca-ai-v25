# V18 — Template + Human Approval Workflow

V18 extends V17 with a safe package production pipeline.

## New capabilities
- `GET /api/ai/package-template?product_id=ID` — read a WooCommerce product and convert it into a normalized Prisca template snapshot.
- `POST /api/ai/approval-request` — QA a package and put it into a persistent human approval queue. No WordPress write occurs.
- `GET /api/package-approvals` — admin-only approval queue.
- `POST /api/package-approvals/review` — admin can approve/reject. Approval creates a WooCommerce **draft** only; publishing remains blocked.
- New `package_approvals` database table.
- Normalized package contract accepts common aliases such as `title` and `selling_price`.

## Safety
- AI service endpoints require `X-Prisca-Service-Key`.
- Human review requires an authenticated admin session.
- WooCommerce creation is forced to `status=draft`.
- No automatic publishing endpoint was added.

## Intended flow
Research/generate → normalize → QA → approval queue → human approve → WooCommerce draft → human publishes manually.
