# V21 – Platform Integrations + Analytics

- Added credential-gated integration registry for WordPress, Meta/Instagram/Facebook, YouTube, Pinterest, Google Search Console and Bing Webmaster.
- Added safe publishing gate: external publishing endpoints require an explicitly approved content asset.
- Added content publishing audit log and platform metrics storage.
- Added Search Console analytics ingestion and Bing URL submission adapters.
- Added Pinterest Pin creation and Meta Page/Instagram publishing adapters.
- Added YouTube adapter scaffolding using OAuth bearer tokens; video uploads remain private by default until the account/project is properly configured.
- Added integration status endpoint and analytics endpoints.
- Credentials remain server-side environment variables; never place them in Android or source code.
