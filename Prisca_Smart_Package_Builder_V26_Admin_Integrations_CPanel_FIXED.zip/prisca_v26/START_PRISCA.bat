@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title Prisca AI Operations Manager - V25
set "APP_DIR=%~dp0"
set "VENV=%APP_DIR%.prisca_venv"
set "PYTHON_CMD="

REM ------------------------------------------------------------
REM 1) Find Python. Prefer the Windows Python launcher, then python.
REM ------------------------------------------------------------
where py >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys; print(sys.version)" >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD (
    where python >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

REM ------------------------------------------------------------
REM 2) If Python is missing, try installing it automatically via winget.
REM ------------------------------------------------------------
if not defined PYTHON_CMD (
    echo.
    echo Python was not found. Trying to install Python automatically...
    where winget >nul 2>&1
    if errorlevel 1 (
        echo.
        echo ERROR: Windows Package Manager (winget) is not available.
        echo Install Python 3.11+ once, then double-click START_PRISCA.bat again.
        pause
        exit /b 1
    )
    winget install --id Python.Python.3.13 -e --accept-source-agreements --accept-package-agreements
    if errorlevel 1 (
        echo.
        echo Python installation failed or was cancelled.
        pause
        exit /b 1
    )
    REM Refresh PATH for this process if Python was installed to the standard location.
    if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set "PYTHON_CMD="%LocalAppData%\Programs\Python\Python313\python.exe""
    if not defined PYTHON_CMD (
        where py >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -3"
    )
    if not defined PYTHON_CMD (
        where python >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo.
    echo ERROR: Python could not be located after installation.
    echo Please restart Windows once and run START_PRISCA.bat again.
    pause
    exit /b 1
)

REM ------------------------------------------------------------
REM 3) Create a private virtual environment inside this folder.
REM    No global pip packages are required.
REM ------------------------------------------------------------
if not exist "%VENV%\Scripts\python.exe" (
    echo.
    echo First run: creating Prisca's private environment...
    %PYTHON_CMD% -m venv "%VENV%"
    if errorlevel 1 (
        echo.
        echo ERROR: Could not create the private Python environment.
        pause
        exit /b 1
    )
)

set "PY=%VENV%\Scripts\python.exe"

REM ------------------------------------------------------------
REM 4) Install/update dependencies automatically.
REM ------------------------------------------------------------
echo.
echo Checking Prisca dependencies...
"%PY%" -m pip install --disable-pip-version-check --no-warn-script-location -r "%APP_DIR%requirements.txt"
if errorlevel 1 (
    echo.
    echo ERROR: Dependency installation failed.
    pause
    exit /b 1
)

REM ------------------------------------------------------------
REM 5) Start V25 and open the dashboard.
REM ------------------------------------------------------------
echo.
echo Starting Prisca V25...
start "Prisca V25 Server" cmd /k "cd /d "%APP_DIR%" && "%PY%" app.py"
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:8765"

echo.
echo ============================================================
echo   PRISCA V25 IS RUNNING
echo   Dashboard: http://127.0.0.1:8765
echo   Keep the Prisca server window open while using the app.
echo ============================================================
echo.
endlocal
exit /b 0
