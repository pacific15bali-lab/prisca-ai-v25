# V26 Windows build

The included `build-v26-windows.yml` is a manual GitHub Actions workflow.

1. Upload `Prisca_Smart_Package_Builder_V26_Admin_Integrations_CPanel.zip` to the GitHub repository root.
2. Upload `.github/workflows/build-v26-windows.yml` to the repository.
3. Open **Actions → Build Prisca V26 for Windows → Run workflow**.
4. Download artifact **Prisca-V26-Windows-One-Click**.
5. Extract it and double-click `START_PRISCA.exe`.

The Windows build is `onedir` for reliability: the user double-clicks one EXE, while its support files remain beside it.
