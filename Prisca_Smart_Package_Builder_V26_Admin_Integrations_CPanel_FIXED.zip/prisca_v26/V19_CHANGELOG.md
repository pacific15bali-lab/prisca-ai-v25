# V19 — 20-Package Generation Engine

Adds a safe, structured package-generation endpoint for the Prisca AI Worker.

## Endpoint
`POST /api/ai/generate-packages`

Header: `X-Prisca-Service-Key`

Example request:
```json
{
  "destination":"Kerala",
  "nights":3,
  "base_route":["Kochi","Munnar","Alleppey"],
  "count":20,
  "brief":{"market":"India","audience":"couples"}
}
```

The engine creates 20 structured package variants with itinerary/content/SEO placeholders and explicit states:
- `research_status: needs_validation`
- `pricing_status: needs_supplier_costs`
- `publish_blocked: true`

This build intentionally does **not** pretend that generated attractions, opening hours, routes, supplier rates, or images are researched. A future research provider validates those fields before human approval.

The existing V16 pricing engine remains the sole source of commercial pricing.
