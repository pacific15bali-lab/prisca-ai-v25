# V24 — Website Lead Intake & Sales Automation

V24 adds the bridge from Prisca's public website/forms into the Sales Worker.

## New
- Secure public `POST /api/leads/webhook` endpoint.
- Shared-secret authentication via `PRISCA_LEAD_WEBHOOK_SECRET`.
- Optional signature validation via `X-Prisca-Signature`.
- Duplicate protection using deterministic intake fingerprints.
- Soft duplicate merge by normalized phone/email.
- Automatic round-robin assignment to active sales agents.
- Automatic first-follow-up task creation.
- Intake source normalization.
- Admin `GET /api/leads/intake-status`.

## Supported payload fields
`name`, `full_name`, `phone`, `mobile`, `email`, `source`, `destination`, `travel_date`, `travellers`, `budget`, `message`, `notes`.

## Safety
The webhook does not send WhatsApp, SMS or email. It only creates/updates internal leads and tasks. Outbound communication remains a separate approved integration.
