# V25 — Vendor + Booking + Operations Worker

V25 connects the WON sales stage to a controlled trip-operations workflow.

## Added
- Automatic operations kickoff when a lead moves to `won`.
- Customer + booking creation from a WON lead with duplicate protection.
- Booking workflow and milestone tracking.
- Supplier/vendor directory.
- Booking service planning for hotel, houseboat, cab, activity and other services.
- Supplier confirmation request queue.
- Supplier confirmation capture with confirmation ID/reference.
- Customer payment tracking and supplier payment tracking.
- Supplier payable/due tracking using existing booking service tables.
- Voucher generation after supplier confirmation.
- Customer communication approval queue (no external send).
- Operations dashboard and Trip Operations UI.

## Safety gates
- No supplier message is sent automatically.
- No customer message is sent automatically.
- No financial payment is executed automatically.
- Voucher generation requires supplier confirmation.
- External providers remain unconfigured until credentials/connectors are added.
