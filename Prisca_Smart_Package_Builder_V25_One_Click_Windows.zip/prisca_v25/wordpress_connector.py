#!/usr/bin/env python3
"""Prisca WordPress/WooCommerce connector.

Read-only by default. Draft creation is explicit and never publishes a product.
Credentials are read from environment variables; never put them in the Android app.
"""
import os, json, base64, time, urllib.request, urllib.error
from urllib.parse import urljoin

class WordPressConnector:
    def __init__(self, base_url=None, username=None, application_password=None, timeout=20):
        self.base_url=(base_url or os.getenv('PRISCA_WP_URL','')).rstrip('/')+'/'
        self.username=username or os.getenv('PRISCA_WP_USER','')
        self.application_password=application_password or os.getenv('PRISCA_WP_APP_PASSWORD','')
        self.timeout=timeout
        if not self.base_url or not self.username or not self.application_password:
            raise ValueError('Set PRISCA_WP_URL, PRISCA_WP_USER and PRISCA_WP_APP_PASSWORD')
        token=base64.b64encode(f'{self.username}:{self.application_password}'.encode()).decode()
        self.headers={'Authorization':'Basic '+token,'User-Agent':'Prisca-AI-Worker/0.1'}

    def request(self, path, method='GET', data=None, params=None):
        url=urljoin(self.base_url, path.lstrip('/'))
        if params:
            from urllib.parse import urlencode
            url += ('&' if '?' in url else '?') + urlencode(params)
        body=None
        headers=dict(self.headers)
        if data is not None:
            body=json.dumps(data,ensure_ascii=False).encode()
            headers['Content-Type']='application/json'
        req=urllib.request.Request(url,data=body,headers=headers,method=method)
        try:
            with urllib.request.urlopen(req,timeout=self.timeout) as r:
                raw=r.read().decode('utf-8','replace')
                return r.status, json.loads(raw) if raw else None
        except urllib.error.HTTPError as e:
            raw=e.read().decode('utf-8','replace')
            try: detail=json.loads(raw)
            except Exception: detail=raw
            raise RuntimeError(f'WordPress HTTP {e.code}: {detail}')

    def health(self):
        start=time.perf_counter()
        status,data=self.request('/wp-json/wp/v2/types')
        return {'ok':status==200,'http_status':status,'response_ms':round((time.perf_counter()-start)*1000,1)}

    def site_info(self):
        status,data=self.request('/wp-json')
        return {'status':status,'name':data.get('name'),'description':data.get('description'),'url':data.get('url'),'home':data.get('home'),'gmt_offset':data.get('gmt_offset')}

    def products(self, per_page=100, page=1):
        status,data=self.request('/wp-json/wc/v3/products',params={'per_page':min(per_page,100),'page':page})
        return {'status':status,'rows':data}

    def product_categories(self, per_page=100):
        status,data=self.request('/wp-json/wc/v3/products/categories',params={'per_page':min(per_page,100)})
        return {'status':status,'rows':data}

    def posts(self, per_page=100, page=1):
        status,data=self.request('/wp-json/wp/v2/posts',params={'per_page':min(per_page,100),'page':page,'context':'edit'})
        return {'status':status,'rows':data}

    def pages(self, per_page=100, page=1):
        status,data=self.request('/wp-json/wp/v2/pages',params={'per_page':min(per_page,100),'page':page,'context':'edit'})
        return {'status':status,'rows':data}

    def plugins(self, per_page=100):
        status,data=self.request('/wp-json/wp/v2/plugins',params={'per_page':min(per_page,100),'context':'edit'})
        return {'status':status,'rows':data}

    def create_product_draft(self, product):
        """Create a WooCommerce product with status=draft. Never publishes."""
        payload=dict(product)
        payload['status']='draft'
        return self.request('/wp-json/wc/v3/products',method='POST',data=payload)

    def audit(self):
        """Non-destructive site audit. Returns data only; no writes."""
        result={'checked_at':time.strftime('%Y-%m-%dT%H:%M:%S'),'site':{},'health':{},'products':{},'categories':{},'plugins':{},'warnings':[]}
        try: result['site']=self.site_info()
        except Exception as e: result['warnings'].append('site_info: '+str(e))
        try: result['health']=self.health()
        except Exception as e: result['warnings'].append('health: '+str(e))
        try:
            p=self.products(); result['products']={'count':len(p.get('rows',[])),'rows':p.get('rows',[])}
        except Exception as e: result['warnings'].append('products: '+str(e))
        try:
            c=self.product_categories(); result['categories']={'count':len(c.get('rows',[])),'rows':c.get('rows',[])}
        except Exception as e: result['warnings'].append('categories: '+str(e))
        try:
            pl=self.plugins(); result['plugins']={'count':len(pl.get('rows',[])),'rows':pl.get('rows',[])}
        except Exception as e: result['warnings'].append('plugins: '+str(e))
        return result

if __name__=='__main__':
    print(json.dumps(WordPressConnector().audit(),indent=2,ensure_ascii=False))
