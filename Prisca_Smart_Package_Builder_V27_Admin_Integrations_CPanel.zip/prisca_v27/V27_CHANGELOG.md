# V27 Change Log

## cPanel install/update safety
- Fixed the V26 `Application domain is required` bug caused by a settings-key mismatch (`cpanel_app_domain` vs `app_domain`).
- cPanel installer now accepts both legacy and canonical configuration keys.
- App domain is normalized automatically: `https://ai.example.com/` becomes `ai.example.com`.
- App path is normalized from either `cpanel_app_path` or `app_path`.
- Existing V26 saved integration settings remain compatible.
- V27 does not reset the local SQLite database during normal startup/update.
- Health endpoint reports V27.

## Important
- Existing `data/prisca.db` and `data/.privacy.key` must be preserved when replacing application files.
- Do not paste API tokens/passwords into chat.
